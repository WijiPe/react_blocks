import React, {Component} from 'react'
import './../Style/style.css'

class Navigation extends Component{
    render(){

        return(
            <div className = "navigation"></div>
        )
    }
}
export default Navigation