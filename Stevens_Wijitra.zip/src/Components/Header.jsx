import React, {Component} from 'react'
import './../Style/style.css'

class Header extends Component{
    render(){

        return(
            <div className = "header"></div>
        )
    }
}
export default Header