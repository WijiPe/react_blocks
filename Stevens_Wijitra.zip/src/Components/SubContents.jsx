import React, {Component} from 'react'
import './../Style/style.css'

class SubContents extends Component{
    render(){

        return(
            <div className = "subcontents"></div>
        )
    }
}
export default SubContents