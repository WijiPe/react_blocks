import React, {Component} from 'react'
import './../Style/style.css'

class Advertisement extends Component{
    render(){

        return(
            <div className = "advertisement"></div>
        )
    }
}
export default Advertisement
